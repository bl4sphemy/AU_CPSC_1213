/**
 This is a simple program to print my student info. 
 Activity 1 
 @author Brian Rawlins – CPSC_1213 - section unknown
 @version 011818 
*/

public class StudentInfo 
{   
    /**
     Prints student info to std output.
     @param args -- (not used).
    */
   public static void main(String[] args)
   {
      System.out.println("Name: Brian Rawlins");
      System.out.println("Previous Computer Courses: ");
      System.out.println("   Intro to Computer Science I (Python), Intro to " 
                         + "Computer Science II (C++), Data Structures(C++)");
   }
}

