/**
 This program outputs the letter J, written in ASCII
 and it uses the word JAVA as it's base. 
 Project_1 
 @author Brian Rawlins – CPSC_1213 - section unknown
 @version 012118 
*/

public class JLetter 
{   
    /**
     This method outputs to std display.
     @param args -- (not used).
    */
   public static void main(String[] args)
   {
      System.out.println("JAVAJAVAJAVA");
      System.out.println("JAVAJAVAJAVA");
      System.out.println("      JAVA  ");
      System.out.println("      JAVA  ");
      System.out.println("      JAVA  ");
      System.out.println("      JAVA  ");
      System.out.println("J     JAVA  ");
      System.out.println("JA    JAVA  ");
      System.out.println(" JAVAJAVA   ");
      System.out.println("  JAVAJA    ");
      System.out.println();
   }
}