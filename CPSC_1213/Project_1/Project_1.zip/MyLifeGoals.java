/**
 This is a simple program to print my short, medium, and longterm goals. 
 Project_1 
 @author Brian Rawlins – CPSC_1213 - section unknown
 @version 012118 
*/

public class MyLifeGoals 
{   
    /**
     Prints my short, medium, and longterm goals to std output.
     @param args -- (not used).
    */
   public static void main(String[] args)
   {
      System.out.println("Brian Rawlins");
      System.out.println();
      System.out.println("Shorterm goals: Graduate with a 3.5 (or better)"
                       + "grade point average in Computer Science from the "
                       + "distinguished Auburn University.");
      System.out.println("Midterm goals:  Take the Graduate Management"
                       + " Admissions Test. Get accepted to a Masters of"
                       + " Business Administration graduate program, and"
                       + " obtain my MBA.");
      System.out.println("Longterm goals: Obtain a new management position."
                       + " Work my way up from mid-level to"
                       + " upper-level management. Eventually I hope to"
                       + " become the CTO for a large company.");
   }
}